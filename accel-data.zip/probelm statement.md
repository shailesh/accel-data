* User comes to the joint and orders a burger
* User can choose the ingrediants for his burger. The ingredients are Bun, Salad, Cheese Slices and Cutlets
* The app should have the following features

* Order a burger
* List All burgers that are ordered along with price.
* Use price calculation service, total Sale
* Search All burgers by Person name, total  sale by person


Sample Input may look like this

Order Burger with the following options

Name or guy who order
Bun = 2 (fix price Rs 5 each