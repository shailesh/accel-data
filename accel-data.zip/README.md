# Case study:

Create an application to track orders for a burger joint User comes to the joint and orders a burger User can choose the ingredients for his burger. The ingredients are Bun, Salad, Cheese Slices and Cutlets The app should have the following features Order a burger List All burgers that are ordered along with price. Use price calculation service, total Sale Search All burgers by Person name, total sale by person Sample Input may look like this Order Burger with the following options Name or guy who order Bun = 2 (fix price Rs 5 each bun) salad = yes or no (price Rs 5) Cheese Slices = (Rs 1 per slice) cutlets = (Rs 2 per piece)

## Software Requirements
Programming languages : Python3
Web Framework         : Django(2.0),Html,Css,Javascript
Database              : Sqlite


#### Setup To Run
1. create a virtual enviornment
2. Activate the env
3. install the requirments
4. run server
5. open localhost:8000 in your browser
```
pip install -r requirements.txt
```
```
python manage.py runserver
```
